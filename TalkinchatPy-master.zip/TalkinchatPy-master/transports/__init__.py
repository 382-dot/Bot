"""TalkinChat protocol adapters."""
